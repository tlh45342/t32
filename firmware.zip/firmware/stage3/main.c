/* T32 C STAGE3 0.0.12 - interactive monitor input editing. */

extern int puts(char *s);
extern int putchar(int ch);
extern int strcmp(char *left, char *right);
extern int t32_getchar(void);

int command_help(void)
{
    puts("help     show commands");
    puts("version  show monitor version");
    puts("bootinfo show boot handoff status");
    puts("mem      show current memory contract");
    puts("halt     leave the monitor");
    return 0;
}

int main(void)
{
    char line[64];
    int done = 0;
    int length;
    int ch;

    puts("T32 Stage3 Monitor 0.0.12");
    puts("Type 'help' for commands.");

    while (done == 0) {
        puts("t32> ");
        length = 0;

        while (length < 63) {
            ch = t32_getchar();

            if (ch == 13) {
                putchar(10);
                break;
            } else if (ch == 10) {
                putchar(10);
                break;
            } else if (ch == 8) {
                if (length > 0) {
                    length = length - 1;
                    putchar(8);
                }
            } else if (ch == 127) {
                if (length > 0) {
                    length = length - 1;
                    putchar(8);
                }
            } else if (ch >= 32) {
                if (ch <= 126) {
                    line[length] = ch;
                    length = length + 1;
                    putchar(ch);
                }
            }
        }

        line[length] = 0;

        if (length == 0) {
            /* Blank line: simply reprompt. */
        } else if (strcmp(line, "help") == 0) {
            command_help();
        } else if (strcmp(line, "version") == 0) {
            puts("T32 Stage3 Monitor 0.0.12");
        } else if (strcmp(line, "bootinfo") == 0) {
            puts("Bootinfo v0.2 handoff OK");
        } else if (strcmp(line, "mem") == 0) {
            puts("Stage3 load address 0x00020000");
            puts("Stage3 stack top    0x0000E000");
        } else if (strcmp(line, "halt") == 0) {
            done = 1;
        } else {
            puts("Unknown command");
        }
    }

    return 42;
}
